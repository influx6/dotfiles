"""Test module for the pyi project"""


class Wheel:
    def __init__(self):
        pass
